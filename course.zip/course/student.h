/**
 * @brief Student type stores a student with fields with fisrt name, last name, id, grades, num_grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50];  /**< the student's first name */
  char last_name[50];  /**< the student's last name */
  char id[11];  /**< the student's id */
  double *grades;   /**< the student's grades */
  int num_grades;   /**< the student's number grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
