var searchData=
[
  ['course_2c_20student_20function_20demonstrations_0',['Course, Student function demonstrations',['../index.html',1,'']]]
];
